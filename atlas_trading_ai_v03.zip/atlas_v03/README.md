# Atlas Trading AI — Version 0.3

Ein Forschungs- und Paper-Trading-Prototyp. **Keine echten Orders, keine automatische Gewinnmaschine.**

## Installation als Update für das vorhandene Streamlit-Projekt

Ersetze **beide Dateien** `app.py` und `engine.py` in der Wurzel des GitHub-Repositories (Branch `main`) durch die Dateien aus diesem Paket. Andere Dateien unverändert lassen; `requirements.txt` des bisherigen Projekts genügt. Nicht nur `app.py` ersetzen: die neue Oberfläche benötigt die neue Schnittstelle von `engine.py`.

Nach GitHub Commit sollte Streamlit Community Cloud die Version neu laden. Im Dashboard steht dann „Version 0.3“.

## Neu

- Kraken EUR-Paare BTC/EUR, ETH/EUR, SOL/EUR; max. 720 OHLC-Kerzen pro Aufruf und Abzug der laufenden Kerze.
- Chronologische Zeitabschnitte: 40% Training, 40% Validierung, 20% Holdout; Strategiewahl **ausschließlich** nach Validierung, Holdout nur als deskriptive Kontrolle.
- Long-only Backtest: nur vorherige Schlusskurs-Signale, Ausführung nächste Kerze zum Open, zusätzliche 0,05% angenommene Slippage je Fill plus Gebühren.
- Offene Positionen werden am Intervallende marktwertbasiert bewertet, **nicht** als abgeschlossene Trades gezählt. Stop-Loss hat bei gleichzeitiger Berührung Vorrang; konservative Gapsimulation.
- Detaillierte Diagnosetabelle mit Ablehnungsgründen; die ursprünglichen Freigaberegeln bleiben bestehen.
- Bei offenen Paper-Positionen wird das Ausstiegssignal der ursprünglichen Strategie geprüft, selbst wenn aktuell keine Strategie für neue Käufe zugelassen ist.
- Geschätzter Portfoliowert bewertet offene Positionen anhand der zuletzt geladenen Kurse (sonst Näherung).

## Bekannte Einschränkungen

1. Kraken REST OHLC liefert höchstens 720 jüngste Kerzen (z. B. ~30 Tage bei 1h, ~120 Tage bei 4h, ~7,5 Tage bei 15m). Ein historischer Langzeitdatensatz benötigt eine andere Quelle. Die dreigeteilte Stichprobe ist statistisch oft sehr klein.
2. Strategien haben weiterhin **feste Parameter**; es gibt noch keine Parametersuche. Die wiederholte Auswahl anhand rollierender Validierung ist keine unabhängige Walk-Forward-Studie. Der Holdout wird bei fortlaufender Nutzung irgendwann wieder eingesehen.
3. Paper-Trading rechnet indikative Trades zum Schlusskurs der letzten abgeschlossenen Kerze ab, keine zuverlässige Echtzeit-Ausführung. Daher **kein** Beleg für handelbare Renditen.
4. Das Streamlit-Dashboard ist **kein 24/7 Worker**; automatischer Seitenrefresh erfordert eine geöffnete aktive Sitzung. SQLite ist auf Streamlit Community Cloud nicht garantiert persistent. Öffentlich zugängliche Besucher können Paper-Daten verändern oder zurücksetzen.
5. Kein Hebel und kein Echtgeld-Ordercode. Historische Rendite ≠ zukünftiger Erfolg. Für die Realisierung wären erheblich mehr unabhängige Daten, realistische Ausführungsmodelle und Schutzmechanismen nötig.

## Lokal testen

```bash
pip install -r requirements.txt
streamlit run app.py
```
