"""Offline tests, no exchange calls and no real orders."""
import sys
import types
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
# Unit tests do not need an installed CCXT dependency or network.
if 'ccxt' not in sys.modules:
    try:
        import ccxt  # noqa
    except ImportError:
        sys.modules['ccxt'] = types.SimpleNamespace()

import numpy as np
import pandas as pd
import engine


def candles(n=720):
    t = np.arange(n)
    close = 100 + np.sin(t / 7) * 4 + t * 0.002
    return pd.DataFrame({
        'timestamp': pd.date_range('2025-01-01', periods=n, freq='h', tz='UTC'),
        'open': close.copy(), 'high': close + 1.0, 'low': close - 1.0,
        'close': close.copy(), 'volume': np.ones(n),
    })


def test_open_trade_does_not_count_as_closed_trade():
    df = candles(60)
    df[["open", "high", "low", "close"]] = [100.0, 100.5, 99.5, 100.0]
    e, x = np.zeros(60, dtype=bool), np.zeros(60, dtype=bool)
    e[10] = True
    r = engine._period_backtest(df, e, x, 10, 60)
    assert r['open_at_end']
    assert r['closed_trades'] == 0
    assert r['profit_factor'] == 0


def test_stop_first_when_stop_and_take_both_touch():
    df = candles(6)
    df.loc[2, ['open', 'high', 'low', 'close']] = [100, 110, 90, 101]
    e, x = np.zeros(6, dtype=bool), np.zeros(6, dtype=bool)
    e[1] = True
    r = engine._period_backtest(df, e, x, 1, 6, fee_rate=0, slippage_rate=0)
    assert r['closed_trades'] >= 1
    assert r['return_pct'] < 0


def test_holdout_does_not_determine_selection():
    df = candles(720)
    before, w1 = engine.evaluate_strategies(df)
    mutated = df.copy()
    mutated.loc[600:, 'close'] = mutated.loc[600:, 'close'] * 1.3
    mutated.loc[600:, 'open'] = mutated.loc[600:, 'open'] * 1.3
    mutated.loc[600:, 'high'] = mutated.loc[600:, 'high'] * 1.3
    mutated.loc[600:, 'low'] = mutated.loc[600:, 'low'] * 1.3
    after, w2 = engine.evaluate_strategies(mutated)
    assert [(r['strategy'], r['validation']) for r in before] == [(r['strategy'], r['validation']) for r in after]
    assert (w1['strategy'] if w1 else None) == (w2['strategy'] if w2 else None)


def test_exit_checks_open_position_without_winner(monkeypatch, tmp_path):
    monkeypatch.setattr(engine, 'DB_PATH', tmp_path / 'paper.sqlite')
    df = candles(260)
    # Buy signal on last candle, then price drop on new candle and no winner.
    def buy_signal(d, s):
        ent = np.zeros(len(d), dtype=bool)
        ext = np.zeros(len(d), dtype=bool)
        ent[-1] = True
        return ent, ext
    monkeypatch.setattr(engine, '_signals', buy_signal)
    action = engine.run_paper_cycle('BTC/EUR', df, 'EMA Trend')
    assert 'GEKAUFT' in action
    df2 = pd.concat([df, df.tail(1).copy()], ignore_index=True)
    df2.loc[len(df2) - 1, 'timestamp'] = df2.loc[len(df2) - 2, 'timestamp'] + pd.Timedelta(hours=1)
    df2.loc[len(df2) - 1, 'close'] = float(df2.loc[len(df2) - 2, 'close']) * 0.90
    action2 = engine.run_paper_cycle('BTC/EUR', df2, strategy_name=None)
    assert 'VERKAUFT' in action2
    assert engine.get_portfolio()['open_positions'] == 0
